# kwa-igbo-to-insibidi

this file is a transliterator that takes latin igbo user input and turns it into nsibidi with or (without- coming soon) the use of tones along with the 
choice of a randomly producing computer generator input or user selected input for a phrase or word.

This file is a JSON dictionary translator used to automatically translate a random Igbo word into the equivalent Nsibidi
using a simple loop where you feed in your Latinized Igbo words and it returns the Nsibidi equivalent.

This simple project can be used in the future for machine learning
if a new word that doesn't exist in the json or foreign phrases are present within a senetence or phrase
another future extension of this program can be to find a new word try and capture it and it's location within the text body 
